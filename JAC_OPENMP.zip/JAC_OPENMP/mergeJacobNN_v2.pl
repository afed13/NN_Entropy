#! /usr/bin/perl -w

#### mergeJacobNN.pl  ####

#checking whether all arguments are present
die "usage: ./mergeJacobNN.pl NN-data Jacobian-data merged-data\n" if @ARGV != 3;

$nn_data = $ARGV[0];      #filename for NN data
$jac_data = $ARGV[1];     #filename for Jacobian data
$out_data = $ARGV[2];     #output filename

#opening data files
open(FDN,"<$nn_data") or die"Cannot open NN-data file $nn_data.\n";
@nndat = <FDN>;      #reading NN data
close(FDN);          #closing file with NN data
open(FDJ,"<$jac_data") or die"Cannot open Jacobian-data file $jac_data.\n";
@jacdat = <FDJ>;     #reading Jacobian data
close(FDJ);          #closing file with Jacobian data

#finding the k-NN number
$k_nn = 0;                      #initial k-NN value
$i = 3;                         #first line with actual data (+1)
while ($k_nn == 0) {            #runs while k-nn is set to zero
    if($nndat[$i] =~ /\d+/) {   #checks if there is a number (\d+) in record
	$i++;                   #if number then next line
    } else {                    #if not a number
	$k_nn = $i-3;           #sets the k-NN to line counter minus starting offset
    }  #end of if $nndata clause
}    #end of while $k_nn loop

print "k-NN = ",$k_nn,"\n";    #reports k-NN to screen

#finding number of records for NN data
$nn_numrec = 0;                       #initial number of NN records
$nn_dim = 0;                          #initial clustersize
$nn_var =0;                           #initial number of variables
foreach $inn (@nndat) {               #runs through all NN records 
    if($inn =~ /Selected Dimensions:/) {    #finds the pattern starting new record
	my @a = split /\s+/,$inn;           #splits the line to get the record description/key
	$nn_dim = &a_dim($a[2]) if($nn_dim < &a_dim($a[2])) ; #checks whether current max clustersize should be updated
	$nn_var++ if(&a_dim($a[2])==1);   #check whether current total number of variables should be updated (only when cs=1)
	$nn_numrec++;                 #updates total number of NN records
    }   #end of if $inn block
}       #end of foreach $inn loop

#finding number of records for jacobian data
$jac_numrec = 0;    #initial number oj Jacobian records
$jac_dim = 0;       #initial clustersize
$jac_var = 0;       #initial number of variables
foreach $ijac (@jacdat) {             #runs through all Jacobian records
    if($ijac =~ /Selected Dimensions:/) {   #finds pattern starting new record
	my @a = split /\s+/,$ijac;          #splits line to get record description/key
	$jac_numrec++;                      #updates total number of JAC records
	$jac_dim = &a_dim($a[2]) if($jac_dim < &a_dim($a[2])) ; #check whether current max clustersize should be updated
	$jac_var++ if(&a_dim($a[2])==1); #check whether current total number of variables should be updated (only when cs=1)
    }   #end of if $ijac block
}       #end of foreach $ijac loop

#calculating the expexted number of records for a given clustersize
$n_exp =0;                                #initial value
for($ii=1; $ii<= $nn_dim; $ii++) {        #runs through all clustersizes       
    $n_exp += &get_exp_num($nn_var,$ii);  #gets the expected number of records for a given clustersize and updates the total
}    #end of for $ii loop

# checks
$nn_dim    == $jac_dim    || die "Clustersize are different !!!\n";
$nn_numrec == $jac_numrec || die "Number of records are not the same !!!\n";
$nn_var    == $jac_var    || die "Number of varaiables are different !!!\n";
$nn_numrec == $n_exp      || die "There is not enough records for a given clustersize!!\n".
    " (present) $nn_numrec != $n_exp (expected) for ClusterSize= $nn_dim\n";

#reporting to the screen
print "NN:  $nn_numrec  Expect.: $n_exp  Dim: $nn_dim Nvar: $nn_var \n";
print "Jac: $jac_numrec Expect.: $n_exp  Dim: $jac_dim Nvar: $jac_var\n";

#NN record hashing
$i_nn=0;          #initial value for searching through NN data, works also as tmp k-NN value
for($i=1; $i<@nndat; $i++) {                #runs through every line of NN data
    my $inn = $nndat[$i];                   #gets the line
    if($inn =~ /Selected Dimensions:/) {    #finds patttern starting NN record
	$idx = (split /\s+/,$inn)[2];       #gets part of hash key that describes cluster composistion
	$i_nn=0;                            #zeroing
    }    #end of if $inn clause
    if($i_nn > 0 && $i_nn <= $k_nn) {       #checks whether tmp k-NN is within permitted range
	my $idcode = "set".$idx."k".$i_nn;  #constructs hash key with cluster structure and k-NN value embedded
	$nn_hash{$idcode} = $inn;           #saves NN value in a hash
	$i_nn++;                            #increases tmp k-NN for the next line
    } else {                                #when tmp k-NN fails outside permitted range is needs resetting
	$i_nn = 0;                          #reset
    }    #end of if $_nn clause
    $i_nn=1 if($nndat[$i] =~ /H:/) ;        #detect beginning of actual data values (next line) and initiates tmp k-NN to 1
}

#jacobian record hashing
foreach $ijac (@jacdat) {       #runs for each line jacobian file
    $idx = (split /\s+/,$ijac)[2] if($ijac =~ /Selected Dimensions:/); #sets part of hash key from the begining description of a JAC record
    if($ijac =~ /Jacobian Factor/) {   #finds pattern with actual value
	my $idcode = "set".$idx;       #sets hash key
	$jac_hash{$idcode} = (split /\s+/,$ijac)[2];  #saves JAC value in hash using hash key
    }    #end of if $ijac clause
}    #end of foreach $ijac loop

my @jac_keys = keys(%jac_hash);  #getting list of hash keys for jacobian data
my @nn_keys = keys(%nn_hash);    #getting list of hash kesy for NN data

#combining jacobian factor with corresponding entropy values
foreach $nnkey (@nn_keys) {           #this loop goes over all NN/k-NN records by coresponding hash keys
    my $jkey = (split /k/,$nnkey)[0]; #obtaining hash key for jacobian data
    my $v_nn  = $nn_hash{$nnkey};     #NN entropy value
    my $v_jac = $jac_hash{$jkey};     #Jacobian factor
    $fin_hash{$nnkey} = $v_nn + $v_jac;       #final calculations       
}    #end of foreach $nnkey loop

#writing results in sorted order
open(FDO,">$out_data");           #opening output file
     print FDO $nndat[0];         #printing first line with number of records and variables
for($size = 1; $size <= $nn_dim; $size++){     #this loop goes over all clustersizes
    @selectedDim = (1 .. $size);               #initiating a list of variables for a given clustersize
    do{    #thid do loop goes over all possible combinations for a given clustersize and number of variables
        $sFields = join(",", @selectedDim);    #setting the first part of the hash key
        print FDO "Selected Dimensions: $sFields\n"; #printing to the output
        print "Selected Dimensions: $sFields"; #on screen reporting
	print FDO "H:\n";                      #printing to the output file for compatibility
	my $tmp_key = "set".$sFields;          #constructing the core part of hash key
	for (my $k=1;$k<=$k_nn;$k++) {         #loop to record entropy data with different k-NN
	    my $idx = $tmp_key."k".$k ;        #constructing hash key
	    print FDO $fin_hash{$idx},"\n";    #actual printing of entropy data from hash
	}    #end of for $k loop
        print " - Done. \n";             #on screen reporting
	print FDO "\n\n";	         #printing two empty lines for data format compatibility
    }while(nextPick($#selectedDim, $nn_var, @selectedDim));  #end of do while loop
}    #end of for $size loop 
close(FDO);           #closing output file

#THE END

#-----------------------------------------------------------
# returns number of variables
sub a_dim {
    my @b = split /\D/,shift;
    my $nd = @b;
    return $nd;
}

#-----------------------------------------------------------
#returns expected total number of records for a given clustersize and number of variables
sub get_exp_num {
    my $dim =shift;
    my $cs  =shift;
    if ($cs == 1) {
	return $dim;
    } elsif($cs == $dim) {
	return 1;
    } else {
	my $v_tmp = 0;
        my $i = 1;
	while($i <=$dim) {
	    my $av1 = $dim - $i;
	    my $av2 = $cs -1;
	    $v_tmp += (&get_exp_num($av1, $av2));
	    $i++;
	}
	return $v_tmp;
    }
}

#----------------------------------------------------------
#picks the next set of variables
sub nextPick{
    my $index = shift;
    my $maxValue = shift;
    if($index < 0){
	return undef;
    }
    my $value = $_[$index] + 1;
    if($value <= $maxValue){
        $_[$index] = $value;
    }
    else{
        $value = nextPick($index - 1, $maxValue - 1, @_);
        if(defined($value)){
            $value++;
            $_[$index] = $value;
        }
    }
    return $value;
}



  
// Program jac_openmp
// multithreaded jacobian correction entropy program
// OpenMP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <omp.h>
#include <cstdlib>
#include <string>
#include <string.h>
#include <vector>
#include <math.h>

#include "jac_openmp.h"

using namespace std;


typedef double	TORS;			// coordinate data type
typedef TORS* TORSpoint;		// a point
typedef TORSpoint* TORSpointArray;	// an array of points 

typedef int CLUS;
typedef CLUS* CLUSpoint;
typedef CLUSpoint* CLUSpointArray;

int getClusNumber(int* minpoint,int *maxpoint,int maxclus,int nvar);
int isTheLast(int* apoint,int* lpoint,int asize,int lsize);
int* getNextCluster2(int* cpoint, int nvar,int maxclus);
int* shiftNextCluster2(int* cpoint, int nvar,int maxclus,int posit);

//const ANNsplitRule def_split		= ANN_KD_SUGGEST;	// def splitting rule
				

int main(int ARGC, char **ARGV) 
{

    if(ARGC <= 1) {
	cout << "Usage: ./jac_openmp.exe nproc < control_file " << endl;
	exit(0);
    }

# ifdef _OPENMP
    int act_proc_num = omp_get_num_procs();
# endif

    int * btype = new int[MAX_VAR];


    char comment[150];
    char getval_f[150];
    char v_opt[2];
    cin.get(comment,150).get();
    cin.get(v_opt,2).get();
    int v_in = strcmp(v_opt,"v");

// getting arguments

    int n_proc = atoi(ARGV[1]);    // number of CPUs to use

    char dfile[150];               // datafile
    cin.get(comment,150).get();
    cin.get(dfile,150).get();

    cin.get(comment,150).get();
    cin.get(getval_f,150).get();
    int f_point = atoi(getval_f);              // first point

    cin.get(comment,150).get();
    cin.get(getval_f,150).get();
    int nrec = atoi(getval_f);     // number of records
    cin.get(comment,150).get();
    cin.get(getval_f,150).get();
    int nvar = atoi(getval_f);      // number of variables

    cin.get(comment,150).get();
    cin.get(getval_f,150).get();
    int maxclus = atoi(getval_f);         // maximum clustersize

    int f_nrec = nrec-f_point+1;


    //printouts for verbose mode
    if(v_in == 0) {
      cout << "\n\n\t Program JAC_ANN_ENTROPY v2.0" <<endl;
      cout << "Datafile:            " << dfile << endl;
      cout << "First point:         " << f_point << endl;
      cout << "Last point:          " << nrec << endl;
      cout << "Number of Records:   " << f_nrec << endl;
      cout << "Number of Variables: " << nvar << endl;
      cout << "Number of requested CPUs:      " << n_proc << endl;
# ifdef _OPENMP
      cout << "Number of available CPUs:      " << act_proc_num << endl;
# endif
      cout << "MaxClus:             " << maxclus << endl;
    }
    
    cout << "Data size: " << nrec << ", dimension: "<< nvar << endl;

    // reading variable types
    cin.get(comment,150).get();
    if(v_in == 0) {
      cout << comment << endl;
    }
    for(int i=0;i<nvar;i++) {
      cin.get(getval_f,150).get();
      if(v_in == 0) {
	cout << getval_f << "\t\t" ;
      }
      char* pch_t;
      int t_type = 0;
      char* ts_t;
      ts_t = &getval_f[0];
      pch_t = strtok(ts_t," \t");
      //      cout << pch_t << endl;
      if(!strcmp(pch_t,"t")) t_type=1;
      if(!strcmp(pch_t,"a")) t_type=2;
      if(!strcmp(pch_t,"b")) t_type=3;

      if(t_type == 0) {
	cout << "\nUnknown variable type: "<< pch_t << endl;
	exit(0);
      }
      pch_t = strtok(NULL," \t");
      int t_idx = atoi(pch_t);
      if(v_in == 0) {
	cout << "Var: " << t_idx << "\t Type: " << t_type << endl;
      }
      btype[t_idx]=t_type;
    }
    cout << "No.	Type" << endl;	
    for(int i=1;i<=nvar;i++) {
      
      cout <<"  " << i <<"\t" ; //<< btype[i] << endl;
      switch(btype[i]) {
      case 1: cout << "t" << endl;
	break;
      case 2: cout << "a" << endl;
	break;
      case 3: cout << "b" << endl;
	break;
      default:
	cout << "ERROR" << endl;
	exit(0);
      }
    }


// restriction checks

    if(nvar <= 0 || nvar > MAX_VAR) {
	cout << "Invalid value of nvar: " << nvar << endl;
	cout << "0 < nvar <= "<< MAX_VAR<< endl;
	exit(0);
    }
    if(nrec <= 0) {
	cout << "Invalid value of nrec: " << nrec << endl;
	exit(0);
    }
    if(n_proc < 0) {
	cout << "Invalid value of n_proc: " << n_proc << endl;
	exit(0);
    }
# ifdef _OPENMP
    if(n_proc > act_proc_num) {
	cout << "Invalid value of n_proc: " << n_proc << endl;
	exit(0);
    }
# endif
     
    if(maxclus <= 0 || maxclus > MAX_CLUSTERSIZE) {
	cout << "Invalid value of maxclus: " << maxclus << endl;
	cout << "0 < maxclus <= "<< MAX_CLUSTERSIZE<< endl;
	exit(0);
    }

// Checking starting points and endpoints
    int * minpoint = new int[maxclus+1];
    int * maxpoint = new int[maxclus+1];
    if(minpoint == NULL) exit(0);
    if(maxpoint == NULL) exit(0);


//setting empty elements for minclus smaller than maxclus
    for(int i=0;i<=maxclus;i++) minpoint[i]=0;    
//
    minpoint[0]=1;		// number of elements
    minpoint[maxclus]=1;	// first cluster
 

    // verbose output
    if(v_in == 0) {
      cout << "minpoint:" <<endl;
      for(int i=0;i<=maxclus;i++) cout << i << "\t" <<minpoint[i] <<endl;
    }

    for(int i=maxclus; i>= 1;i--) {
      maxpoint[i]=nvar-maxclus+i;
    }	
    maxpoint[0]=maxclus;

   // verbose output
    if(v_in == 0) {
      cout << "maxpoint:" <<endl;
      for(int i=0;i<=maxclus;i++) cout << i << "\t" <<maxpoint[i] <<endl;
    }

    int t_of = 0;				// TODO remove t_of

// SETTING CLUSTERS

    // getting number of clusters
    int numclus = getClusNumber(minpoint,maxpoint,maxclus,nvar);
    
    // clusters array

    CLUSpointArray csarray =new CLUSpoint[numclus+1];

    //initial settings
    for(int i=0;i<=numclus;i++) { 
      csarray[i] = new CLUS[maxclus+1];
      for(int k=0;k<=maxclus;k++) {
	csarray[i][k] = 0 ;
      }
    }

    //first and last array points
    for(int i=0;i<=maxclus;i++) {
	csarray[1][i]=minpoint[i];
	csarray[numclus][i]=maxpoint[i];
    }
   

    for(int i=2;i<numclus;i++) {
      int * cst= new int[maxclus+1];
      for(int k=0;k<=maxclus;k++) cst[k]=csarray[i-1][k];
      int* tt = getNextCluster2(cst,nvar,maxclus);
      for(int k=0;k<=maxclus;k++) csarray[i][k] = tt[k];
      delete[] cst;
    }

    if(v_in == 0) {
      cout << "Total number of clusters: "<< numclus << endl;
    }

// INITIAL SETTINGS
    cout<<setprecision(NUMBER_PREC);   // setting printout's decimal precision

    if(v_in == 0) {
      cout << "Data Reading Initiated. " << endl;;
    }


// DATA ARRAY
    TORSpointArray ddat = new TORSpoint[nrec];

    // DATA EXTRACTION
    ifstream indata(dfile);
    int i_line = 0;        
    if(indata.is_open()) {
      string t2line;
      string tline;
      while(i_line < nrec  + f_point - 1) {   
	getline (indata,tline);
	if(i_line >= f_point -1) {
	  char* pch;
	  char* ts;
	  t2line = tline;
	  ts = &tline[0];
	  int idx = 0;
	  pch = strtok(ts," \t");
	  int kk_line = i_line - f_point + 1;
	  ddat[kk_line] =  new TORS[nvar-t_of];
	  while (pch != NULL) {
	    if(idx >= t_of) {
	      ddat[kk_line][idx-t_of] =  atof(pch);
	    }
	    pch = strtok(NULL," \t");
	    idx++;
	  }
	  if(idx != nvar) {
	    cout << "Set and actual number of variables are different!!"<<endl;
	    cout << "Line: "<<i_line<< "\t  Record# : " <<kk_line << endl;
	    cout << "\tInitial: "<<nvar<<"\t\tActual: "<< idx <<endl;
	    cout << "It could be something wrong with data or input parameters."<<endl; 
	    exit(0);
	  }
	} // end of if(i_line >= f_point)
	i_line++;
      } // end of  while(i_line < nrec  + f_point - 1)
    } else {
      cout << "Unable to open datafile: "<< dfile << endl;
      exit(0);
    }
    indata.close();
// end of data reading

    if(v_in == 0) {
      cout << "Data Reading Done. " << i_line << " records extracted" << endl << endl;;
    }

    // setting the number of cpus used in calculations
# ifdef _OPENMP
    if(n_proc != 0) {
      omp_set_num_threads(n_proc);
    }
# endif


// LOG loop
    double * logsum = new double[MAX_VAR+1];
#pragma omp parallel for shared(ddat,logsum)
    for(int ifx=1;ifx<=nvar;ifx++) {
      double d_logsum = 0.0;
      if(btype[ifx]==3) {
	for(int i=0;i<nrec;i++) {
	  d_logsum += 2*log(ddat[i][ifx-1]);
	}
      }
      if(btype[ifx]==2) {
	for(int i=0;i<nrec;i++) {
	  d_logsum += log(sin(ddat[i][ifx-1]));
	}
      }
      logsum[ifx]=d_logsum;
    }
    // end of omp prallel region

    if(v_in == 0) {
      for(int ifx=1;ifx<=nvar;ifx++) {
	cout << "Var: " << ifx << "\t logsum: "<< logsum[ifx] << endl;
      }
      cout << endl;
    }


//Main loop
#pragma omp barrier
#pragma omp parallel for shared(ddat,csarray)  schedule(dynamic) 
    for(int ix=1;ix<=numclus;ix++) {
      
      int csize = csarray[ix][0];     //current number of columns
      int * csarr = new int[csize];   //array with selected columns
      int ct = 0;
      for(int k= maxclus - csarray[ix][0] + 1;k<=maxclus;k++) {
	csarr[ct]=csarray[ix][k];
	ct++;
      }
      double jac_corr = 0;
      for(int kz=0; kz<csize; kz++) {
	int idxk = csarr[kz] - t_of;     
	jac_corr += logsum[idxk];
      }


#pragma omp critical 
      {
 
	if(v_in == 0) {
	  cout << "Cluster# "<< ix << endl; // <<" BF: "<< bf_v << "\t BF_TOT: "<< bf_sum << endl;
	}
	cout <<"Selected Dimensions: ";
	int ctt = 0;
	for(int k= maxclus - csarray[ix][0] + 1;k<=maxclus;k++) {
	  csarr[ctt]=csarray[ix][k];
	  ctt++;
	}
	if(csize>1) {
	  for(int k=0;k<csize-1;k++) {
	    cout << csarr[k] <<",";
	  }
	}
	cout << csarr[csize-1];

	cout << endl <<"Dimension Types    : ";
//TODO print types

	if(csize>1) {
	  for(int k=0;k<csize-1;k++) {
	    //	    cout << csarr[k] <<",";
	    switch(btype[csarr[k]]) {
	    case 1: cout << "t ";
	      break;
	    case 2: cout << "a ";
	      break;
	    case 3: cout << "b ";
	      break;
	    default:
	      cout << "ERROR" << endl;
	      exit(0);
	    }
	  }
	} // end of if(csize>1)
	switch(btype[csarr[csize-1]]) {
	case 1: cout << "t" << endl;
	  break;
	case 2: cout << "a" << endl;
	  break;
	case 3: cout << "b" << endl;
	  break;
	default:
	  cout << "ERROR" << endl;
	  exit(0);
	}



	//	cout << endl;	
	cout << "Jacobian Factor: \t\t";
	double fin_jac_corr = jac_corr/(f_nrec);
	cout << fin_jac_corr << endl << endl;
      }

      delete[] csarr;
	
    }  //end of main loop

// MAIN PROGRAM memory release

    for(int jz=0; jz<numclus+1; jz++) {
      delete csarray[jz];
    }    
    delete[] csarray;
    for(int jz=0; jz<nrec; jz++) {
      delete ddat[jz];
    }    
    delete[] ddat;    // removing data from memory
    delete[] minpoint;
    delete[] maxpoint;
    delete[] logsum;
    delete[] btype;

    if(v_in == 0) {
      cout << "All " << numclus << " clusters done." << endl;
    }

    return 0;
}   // end of program

//==========================================================================================//




// getting the number of expected clusters
int getClusNumber(int* minpoint,int* maxpoint,int maxclus,int nvar){

  int numcs = 1;
  int* fpoint = new int[maxclus+1];
   
  for(int i=0;i<=maxclus;i++) fpoint[i]=minpoint[i];
  
  while(isTheLast(fpoint,maxpoint,fpoint[0],maxclus) == 0) {
    fpoint = getNextCluster2(fpoint,nvar,maxclus);
    numcs++;
  }
  delete[] fpoint;
  return numcs;  // returns number of clusters
}

//-------------------------------------------------------------------

// check whether this is the final cluster
int isTheLast(int* apoint,int* lpoint,int asize,int maxclus) {
    int rvalue = 1;
    if(asize != maxclus) {
	rvalue = 0;
    } else {
      for(int i=1;i<=maxclus;i++) {
	if(apoint[i] != lpoint[i]) rvalue=0;
      }
    }
    return rvalue;
}

//--------------------------------------------------------------------

// gets next cluster
int* getNextCluster2(int* cpoint, int nvar,int maxclus) {

  cpoint[maxclus]++;
  if(cpoint[maxclus]>nvar) {
    cpoint = shiftNextCluster2(cpoint,nvar,maxclus,maxclus);
  }
  return cpoint;
}

//--------------------------------------------------------------------

// increase cluster by one
int* shiftNextCluster2(int* cpoint, int nvar,int maxclus,int posit) {
  int* tpoint = new int[maxclus+1];   
  int av = 0;
  for(int i = 0;i<= maxclus;i++) {
    av = cpoint[i];
    tpoint[i]=av;
  }

  cpoint[posit-1]++;

  if(posit-1 == 0) cout << "ERROR" << endl;

  if(cpoint[posit-1] < nvar-posit+maxclus) { 
    for(int i=posit;i<=maxclus;i++) {
      cpoint[i]=cpoint[posit-1]+i-posit+1;
    }


    if(cpoint[maxclus] > nvar) {
      for(int i = 0;i<= maxclus;i++) {
	av = tpoint[i];
	cpoint[i]=av;
      }

      cpoint = shiftNextCluster2(cpoint,nvar,maxclus,posit-1);

    }
  

  } else {
    for(int i = 0;i<= maxclus;i++) {
      av = tpoint[i];
      cpoint[i]=av;
    }
    cpoint = shiftNextCluster2(cpoint,nvar,maxclus,posit-1);
  }

  int counter = 0;
  for(int i=1;i<=maxclus;i++) {
    if(cpoint[i]>0) counter++;
  }
  if(counter!=cpoint[0]) cpoint[0]=counter;
  delete[] tpoint;
  return cpoint;
}



#! /usr/bin/perl -w

$ff=$ARGV[0];

$s_end = `cat $ff | wc -l`;

open(FHH,"<$ff");
@asd = <FHH>;
close(FHH);


@bb = sort {$a<=>$b} @asd;

$start = 0;
$tcount = 0;
$pv = -9898989898989898989.0;
foreach $i (0..$s_end-1) {
    if($start != 0) {
	$tcount++ if($bb[$i] == $pv);
	$pv = $bb[$i];
    } else {
	$pv = $bb[$i];
	$start = 1;
    }
}

print "  File: $ff  Number of Ties: $tcount\n";

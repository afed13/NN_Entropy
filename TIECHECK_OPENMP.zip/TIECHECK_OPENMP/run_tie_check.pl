#! /usr/bin/perl -w

die("Usage: run_tie_check.pl datafile\n") if(@ARGV != 1) ;


$datafile = $ARGV[0];
$nvar = `head -1 $datafile | wc -w` +0;
$nrec = `cat $datafile | wc -l` +0;

$| = 1;


print "\n\t\t TIE CHECKER \n";
print "\tDatafile: $datafile\n";
print "\tNumber of Variables : $nvar\n";
print "\tNumber of Records   : $nrec\n"; 

$n_ties = 0;
for($i=1; $i<=$nvar; $i++) {
    $f_tmp = "var_".$i;
    system("./cutpl.pl $i s=1,$nrec $datafile > $f_tmp");
    $vv = `./tie_ch1.pl $f_tmp`;
    @ds = split /\s+/,$vv;
    print ($vv);
    $n_ties += $ds[6] + 0;

    unlink $f_tmp;
}

print "Total number of ties: $n_ties \n";
print "\n Done\n\n";

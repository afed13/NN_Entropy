#! /usr/bin/perl -w

if(@ARGV != 3) {
	die("Usage: cutpl colums s=start,end datafile \n");
}

$datafile = $ARGV[2];
$cols     = $ARGV[0];
$sels     = $ARGV[1];
#print $datafile,"\n";
#print $cols,"2222\n";

@colums = split /\D/,$cols;
@sel_id = split /\D+|\s+/,$sels;


$s_start = $sel_id[1];
$s_end   = $sel_id[2];

die("Wrong sample selection\n START=$_start>=END=$s_end\n ") 
	if($s_start >= $s_end);

open(FDH,"<$datafile");
if($s_start > 2) {
  foreach(1..$s_start-1) {
    $line = <FDH>;
  }
}
foreach($s_start..$s_end) {

	$line = <FDH>;
        $line =~ s/^\s+//;
        @sline = split /\s+/,$line;
	foreach my $id(@colums) {
		print "  ",$sline[$id-1],"\t";
	}
        print "\n";
}
close(FDH);

  
// Program tie_check_mt
// multithreaded tie_check

#include <iostream>
#include <iomanip>
#include <fstream>
#include <omp.h>
#include <cstdlib>
#include <string>
#include <string.h>

using namespace std;

typedef double	TORS;			// coordinate data type
typedef TORS* TORSpoint;		// a point
typedef TORSpoint* TORSpointArray;	// an array of points 

int f_sort(double *a, long f_nrec); 
void MergeSort(double values[], int first, int last, long n_items);
void heapsort(double values[], long n_items);


int main(int ARGC, char **ARGV) 
{

  if(ARGC != 2) {
    cout << "Usage: ./tie_check.exe nproc < control_file  " << endl;
    exit(0);
  }
  
# ifdef _OPENMP
  int act_proc_num = omp_get_num_procs();
# endif

  char comment[150];
  char getval_f[150];
  char v_opt[2];
  cin.get(comment,150).get();
  cin.get(v_opt,2).get();
  int v_in = strcmp(v_opt,"v");

  int n_proc = atoi(ARGV[1]);    // number of threadss to use

  char dfile[150];               // datafile
  cin.get(comment,150).get();
  cin.get(dfile,150).get();
  cin.get(comment,150).get();
  cin.get(getval_f,150).get();
  long nrec = atol(getval_f);     // number of records
  cin.get(comment,150).get();
  cin.get(getval_f,150).get();
  int nvar = atoi(getval_f);      // number of variables


  //  int nvar = atoi(ARGV[3]);
  //  long nrec = atol(ARGV[2]);
  //  int n_proc = atoi(ARGV[4]);
  // char *dfile = ARGV[1];

  cout << "\n\t Program TIE_CHECK v2.1" << endl << endl;
  if(v_in==0) {
    cout << "Verbose output activated." <<endl;
  }
  cout << "Datafile:            " << dfile << endl;
  cout << "Number of Records:   " << nrec << endl;
  cout << "Number of Variables: " << nvar << endl;
  cout << "Number of requested threads: " << n_proc << endl;
  cout << "Number of available CPUs:    " << act_proc_num << endl;

 



  TORSpointArray ddat = new TORSpoint[nvar];
  for(int i=0; i<nvar;i++) {
      ddat[i] =  new TORS[nrec];
  }

  int * nties = new int[nvar];

  cout<<setprecision(18);


  for(int i=0;i<nvar;i++) {
    nties[i] = 0;
  }

  // reading data
  ifstream indata(dfile);
  int i_line = 0;         // no1
  if(indata.is_open()) {
    string t2line;
    string tline;
    while(i_line < nrec  ) {    //no1
      getline (indata,tline);
      char *pch;
      char *ts;
      t2line = tline;
      ts = &tline[0];
      int idx = 0;
      pch = strtok(ts," \t");
      while (pch != NULL) {
	ddat[idx][i_line] = atof(pch);
	pch = strtok(NULL," \t");
	idx++;
      }
      if(idx != nvar) {
	cout << "invalid number of variables "<<idx<<endl;
      }
      //	    cout << endl;
      i_line++;
    }

  } else {
    cout << "Unable to open datafile: "<< dfile << endl;
  }
  indata.close();
  cout << i_line << "  records were retrieved." << endl;
// end of data reading

// sorting

  int nties_tot = 0;

  omp_set_num_threads(n_proc);
#pragma omp parallel for shared(ddat,nties,nties_tot) schedule(dynamic) ordered
  for(int ix=0;ix<nvar;ix++) {	    
    double *a = new double[nrec+1];  //no1????????????

    for(int k=0;k<nrec;k++) {   //no1
      a[k+1] = ddat[ix][k];
    }	

    nties[ix] = f_sort(a,nrec);
#pragma omp ordered //critical
    {
      nties_tot += nties[ix];
      int ivar = ix+1;
      if(v_in == 0) {
	cout << "Variable " << ivar << " has " << nties[ix] << "  tie(s)" << endl;
      }
    }
    delete[] a;
   
  }// end of multithreaded block

// end of sorting

//  for(long i=1;i<=nvar;i++) {
//    cout << "Variable " << i << " has " << nties[i-1] << "  tie(s)" << endl;
//  }
    
  cout << "\n\t Total number of ties: " << nties_tot << endl<< endl<< endl;

  // memory reclamation
  for(int i=0; i<nvar;i++) {
      delete ddat[i];
  }
  delete[] ddat;
  delete[] nties;    


  return 0;


} // end of program



//=====================================================================

// sorting
int f_sort(double a[],long f_nrec) {
    
    int i_rep = 0;

//    MergeSort(a,0,f_nrec-1,f_nrec); //no1

    heapsort(a,f_nrec);

    double rep = a[1];  
    for(int i=2;i<=f_nrec;i++) {  //no1
	if(a[i]==rep) {
	    i_rep++;
	}
	rep = a[i];
    }
    return i_rep;

}

//---------------------------------------------------------------


void Merge(double values[], int leftFirst, int leftLast,
	   int rightFirst, int rightLast, long n_items)
// Post: values[leftFirst]..values[leftLast] and
//       values[rightFirst]..values[rightLast] have been merged.
//       values[leftFirst]..values[rightLast] are now sorted.
{
  double * tempArray = new double[n_items];
  int index = leftFirst;
  int saveFirst = leftFirst;
  while ((leftFirst <= leftLast) && (rightFirst <= rightLast))
  {
    if (values[leftFirst] < values[rightFirst])
    {
      tempArray[index] = values[leftFirst];
      leftFirst++;
    }
    else
    {
      tempArray[index] = values[rightFirst];
      rightFirst++;
    }
    index++;
  }
  while (leftFirst <= leftLast)
  // Copy remaining items from left half.
  {
    tempArray[index] = values[leftFirst];
    leftFirst++;
    index++;
  }
  while (rightFirst <= rightLast)
  // Copy remaining items from right half.
  {
    tempArray[index] = values[rightFirst];
    rightFirst++;
    index++;
  }
  for (index = saveFirst; index <= rightLast; index++)
    values[index] = tempArray[index];
  delete[] tempArray;
}

//---------------------------------------------------------------

void MergeSort(double values[], int first, int last, long n_items)
// Post: The elements in values are sorted by key.
{
  if (first < last)
  {
    int middle = (first + last) / 2;
    MergeSort(values, first, middle, n_items);
    MergeSort(values, middle + 1, last, n_items);
    Merge(values, first, middle, middle + 1, last, n_items);
  }
}
//---------------------------------------------------------------


void heapsort(double values[], long n_items) {
    long i,ir,j,k;
    double rra;

    if(n_items<2) return;
    k=(n_items >> 1)+1;
    ir=n_items;

    for(;;) {
	if(k>1) {
	    --k;
	    rra = values[k];
	} else {
	    rra=values[ir];
	    values[ir]=values[1];
	    if(--ir == 1) {
		values[1]=rra;
		break;
	    }
	}
	i=k;
	j=k+1;
	while(j<= ir) {
	    if(j < ir && values[j] < values[j+1]) j++;
	    if(rra<values[j]) {
		values[i]=values[j];
		i=j;
		j<<= 1;
	    } else break;


	}
	values[i]=rra;
    }
    return;
}
